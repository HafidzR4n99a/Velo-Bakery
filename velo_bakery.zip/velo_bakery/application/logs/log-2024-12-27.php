<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-27 12:18:15 --> Config Class Initialized
INFO - 2024-12-27 12:18:15 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:18:15 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:18:15 --> Utf8 Class Initialized
INFO - 2024-12-27 12:18:15 --> URI Class Initialized
INFO - 2024-12-27 12:18:15 --> Router Class Initialized
INFO - 2024-12-27 12:18:15 --> Output Class Initialized
INFO - 2024-12-27 12:18:15 --> Security Class Initialized
DEBUG - 2024-12-27 12:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:18:15 --> Input Class Initialized
INFO - 2024-12-27 12:18:15 --> Language Class Initialized
INFO - 2024-12-27 12:18:15 --> Loader Class Initialized
INFO - 2024-12-27 12:18:15 --> Helper loaded: url_helper
INFO - 2024-12-27 12:18:15 --> Helper loaded: form_helper
INFO - 2024-12-27 12:18:15 --> Database Driver Class Initialized
INFO - 2024-12-27 12:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:18:15 --> Controller Class Initialized
INFO - 2024-12-27 12:18:15 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:18:15 --> Final output sent to browser
DEBUG - 2024-12-27 12:18:15 --> Total execution time: 0.0388
INFO - 2024-12-27 12:18:16 --> Config Class Initialized
INFO - 2024-12-27 12:18:16 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:18:16 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:18:16 --> Utf8 Class Initialized
INFO - 2024-12-27 12:18:16 --> URI Class Initialized
INFO - 2024-12-27 12:18:16 --> Router Class Initialized
INFO - 2024-12-27 12:18:16 --> Output Class Initialized
INFO - 2024-12-27 12:18:16 --> Security Class Initialized
DEBUG - 2024-12-27 12:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:18:16 --> Input Class Initialized
INFO - 2024-12-27 12:18:16 --> Language Class Initialized
ERROR - 2024-12-27 12:18:16 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:18:17 --> Config Class Initialized
INFO - 2024-12-27 12:18:17 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:18:17 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:18:17 --> Utf8 Class Initialized
INFO - 2024-12-27 12:18:17 --> URI Class Initialized
INFO - 2024-12-27 12:18:17 --> Router Class Initialized
INFO - 2024-12-27 12:18:17 --> Output Class Initialized
INFO - 2024-12-27 12:18:17 --> Security Class Initialized
DEBUG - 2024-12-27 12:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:18:17 --> Input Class Initialized
INFO - 2024-12-27 12:18:17 --> Language Class Initialized
INFO - 2024-12-27 12:18:17 --> Loader Class Initialized
INFO - 2024-12-27 12:18:17 --> Helper loaded: url_helper
INFO - 2024-12-27 12:18:17 --> Helper loaded: form_helper
INFO - 2024-12-27 12:18:17 --> Database Driver Class Initialized
INFO - 2024-12-27 12:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:18:17 --> Controller Class Initialized
INFO - 2024-12-27 12:18:17 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:18:17 --> Final output sent to browser
DEBUG - 2024-12-27 12:18:17 --> Total execution time: 0.0381
INFO - 2024-12-27 12:18:32 --> Config Class Initialized
INFO - 2024-12-27 12:18:32 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:18:32 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:18:32 --> Utf8 Class Initialized
INFO - 2024-12-27 12:18:32 --> URI Class Initialized
INFO - 2024-12-27 12:18:32 --> Router Class Initialized
INFO - 2024-12-27 12:18:32 --> Output Class Initialized
INFO - 2024-12-27 12:18:32 --> Security Class Initialized
DEBUG - 2024-12-27 12:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:18:32 --> Input Class Initialized
INFO - 2024-12-27 12:18:32 --> Language Class Initialized
ERROR - 2024-12-27 12:18:32 --> 404 Page Not Found: Edit_kue/2
INFO - 2024-12-27 12:18:35 --> Config Class Initialized
INFO - 2024-12-27 12:18:35 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:18:35 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:18:35 --> Utf8 Class Initialized
INFO - 2024-12-27 12:18:35 --> URI Class Initialized
INFO - 2024-12-27 12:18:35 --> Router Class Initialized
INFO - 2024-12-27 12:18:35 --> Output Class Initialized
INFO - 2024-12-27 12:18:35 --> Security Class Initialized
DEBUG - 2024-12-27 12:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:18:35 --> Input Class Initialized
INFO - 2024-12-27 12:18:35 --> Language Class Initialized
INFO - 2024-12-27 12:18:35 --> Loader Class Initialized
INFO - 2024-12-27 12:18:35 --> Helper loaded: url_helper
INFO - 2024-12-27 12:18:35 --> Helper loaded: form_helper
INFO - 2024-12-27 12:18:35 --> Database Driver Class Initialized
INFO - 2024-12-27 12:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:18:35 --> Controller Class Initialized
DEBUG - 2024-12-27 12:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-27 12:18:35 --> Upload Class Initialized
INFO - 2024-12-27 12:18:35 --> Form Validation Class Initialized
INFO - 2024-12-27 12:20:34 --> Config Class Initialized
INFO - 2024-12-27 12:20:34 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:34 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:34 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:34 --> URI Class Initialized
INFO - 2024-12-27 12:20:34 --> Router Class Initialized
INFO - 2024-12-27 12:20:34 --> Output Class Initialized
INFO - 2024-12-27 12:20:34 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:34 --> Input Class Initialized
INFO - 2024-12-27 12:20:34 --> Language Class Initialized
ERROR - 2024-12-27 12:20:34 --> 404 Page Not Found: Edit_kue/index
INFO - 2024-12-27 12:20:36 --> Config Class Initialized
INFO - 2024-12-27 12:20:36 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:36 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:36 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:36 --> URI Class Initialized
INFO - 2024-12-27 12:20:36 --> Router Class Initialized
INFO - 2024-12-27 12:20:36 --> Output Class Initialized
INFO - 2024-12-27 12:20:36 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:36 --> Input Class Initialized
INFO - 2024-12-27 12:20:36 --> Language Class Initialized
INFO - 2024-12-27 12:20:36 --> Loader Class Initialized
INFO - 2024-12-27 12:20:36 --> Helper loaded: url_helper
INFO - 2024-12-27 12:20:36 --> Helper loaded: form_helper
INFO - 2024-12-27 12:20:36 --> Database Driver Class Initialized
INFO - 2024-12-27 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:20:36 --> Controller Class Initialized
INFO - 2024-12-27 12:20:36 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:20:36 --> Final output sent to browser
DEBUG - 2024-12-27 12:20:36 --> Total execution time: 0.0445
INFO - 2024-12-27 12:20:37 --> Config Class Initialized
INFO - 2024-12-27 12:20:37 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:37 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:37 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:37 --> URI Class Initialized
INFO - 2024-12-27 12:20:37 --> Router Class Initialized
INFO - 2024-12-27 12:20:37 --> Output Class Initialized
INFO - 2024-12-27 12:20:37 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:37 --> Input Class Initialized
INFO - 2024-12-27 12:20:37 --> Language Class Initialized
ERROR - 2024-12-27 12:20:37 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:20:38 --> Config Class Initialized
INFO - 2024-12-27 12:20:38 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:38 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:38 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:38 --> URI Class Initialized
INFO - 2024-12-27 12:20:38 --> Router Class Initialized
INFO - 2024-12-27 12:20:38 --> Output Class Initialized
INFO - 2024-12-27 12:20:38 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:38 --> Input Class Initialized
INFO - 2024-12-27 12:20:38 --> Language Class Initialized
INFO - 2024-12-27 12:20:38 --> Loader Class Initialized
INFO - 2024-12-27 12:20:38 --> Helper loaded: url_helper
INFO - 2024-12-27 12:20:38 --> Helper loaded: form_helper
INFO - 2024-12-27 12:20:38 --> Database Driver Class Initialized
INFO - 2024-12-27 12:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:20:38 --> Controller Class Initialized
INFO - 2024-12-27 12:20:38 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:20:38 --> Final output sent to browser
DEBUG - 2024-12-27 12:20:38 --> Total execution time: 0.0448
INFO - 2024-12-27 12:20:38 --> Config Class Initialized
INFO - 2024-12-27 12:20:38 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:38 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:38 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:38 --> URI Class Initialized
INFO - 2024-12-27 12:20:38 --> Router Class Initialized
INFO - 2024-12-27 12:20:38 --> Output Class Initialized
INFO - 2024-12-27 12:20:38 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:38 --> Input Class Initialized
INFO - 2024-12-27 12:20:38 --> Language Class Initialized
ERROR - 2024-12-27 12:20:38 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:20:39 --> Config Class Initialized
INFO - 2024-12-27 12:20:39 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:39 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:39 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:39 --> URI Class Initialized
INFO - 2024-12-27 12:20:39 --> Router Class Initialized
INFO - 2024-12-27 12:20:39 --> Output Class Initialized
INFO - 2024-12-27 12:20:39 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:39 --> Input Class Initialized
INFO - 2024-12-27 12:20:39 --> Language Class Initialized
INFO - 2024-12-27 12:20:39 --> Loader Class Initialized
INFO - 2024-12-27 12:20:39 --> Helper loaded: url_helper
INFO - 2024-12-27 12:20:39 --> Helper loaded: form_helper
INFO - 2024-12-27 12:20:39 --> Database Driver Class Initialized
INFO - 2024-12-27 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:20:39 --> Controller Class Initialized
INFO - 2024-12-27 12:20:39 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:20:39 --> Final output sent to browser
DEBUG - 2024-12-27 12:20:39 --> Total execution time: 0.0401
INFO - 2024-12-27 12:20:39 --> Config Class Initialized
INFO - 2024-12-27 12:20:39 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:39 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:39 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:39 --> URI Class Initialized
INFO - 2024-12-27 12:20:39 --> Router Class Initialized
INFO - 2024-12-27 12:20:39 --> Output Class Initialized
INFO - 2024-12-27 12:20:39 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:39 --> Input Class Initialized
INFO - 2024-12-27 12:20:39 --> Language Class Initialized
INFO - 2024-12-27 12:20:39 --> Loader Class Initialized
INFO - 2024-12-27 12:20:39 --> Helper loaded: url_helper
INFO - 2024-12-27 12:20:39 --> Helper loaded: form_helper
INFO - 2024-12-27 12:20:39 --> Database Driver Class Initialized
INFO - 2024-12-27 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:20:39 --> Controller Class Initialized
INFO - 2024-12-27 12:20:39 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:20:39 --> Final output sent to browser
DEBUG - 2024-12-27 12:20:39 --> Total execution time: 0.0446
INFO - 2024-12-27 12:20:40 --> Config Class Initialized
INFO - 2024-12-27 12:20:40 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:40 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:40 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:40 --> URI Class Initialized
INFO - 2024-12-27 12:20:40 --> Router Class Initialized
INFO - 2024-12-27 12:20:40 --> Output Class Initialized
INFO - 2024-12-27 12:20:40 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:40 --> Input Class Initialized
INFO - 2024-12-27 12:20:40 --> Language Class Initialized
ERROR - 2024-12-27 12:20:40 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:20:41 --> Config Class Initialized
INFO - 2024-12-27 12:20:41 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:41 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:41 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:41 --> URI Class Initialized
INFO - 2024-12-27 12:20:41 --> Router Class Initialized
INFO - 2024-12-27 12:20:41 --> Output Class Initialized
INFO - 2024-12-27 12:20:41 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:41 --> Input Class Initialized
INFO - 2024-12-27 12:20:41 --> Language Class Initialized
INFO - 2024-12-27 12:20:41 --> Loader Class Initialized
INFO - 2024-12-27 12:20:41 --> Helper loaded: url_helper
INFO - 2024-12-27 12:20:41 --> Helper loaded: form_helper
INFO - 2024-12-27 12:20:41 --> Database Driver Class Initialized
INFO - 2024-12-27 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:20:41 --> Controller Class Initialized
INFO - 2024-12-27 12:20:41 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:20:41 --> Final output sent to browser
DEBUG - 2024-12-27 12:20:41 --> Total execution time: 0.0321
INFO - 2024-12-27 12:20:43 --> Config Class Initialized
INFO - 2024-12-27 12:20:43 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:43 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:43 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:43 --> URI Class Initialized
INFO - 2024-12-27 12:20:43 --> Router Class Initialized
INFO - 2024-12-27 12:20:43 --> Output Class Initialized
INFO - 2024-12-27 12:20:43 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:43 --> Input Class Initialized
INFO - 2024-12-27 12:20:43 --> Language Class Initialized
ERROR - 2024-12-27 12:20:43 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:20:45 --> Config Class Initialized
INFO - 2024-12-27 12:20:45 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:20:45 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:20:45 --> Utf8 Class Initialized
INFO - 2024-12-27 12:20:45 --> URI Class Initialized
INFO - 2024-12-27 12:20:45 --> Router Class Initialized
INFO - 2024-12-27 12:20:45 --> Output Class Initialized
INFO - 2024-12-27 12:20:45 --> Security Class Initialized
DEBUG - 2024-12-27 12:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:20:45 --> Input Class Initialized
INFO - 2024-12-27 12:20:45 --> Language Class Initialized
INFO - 2024-12-27 12:20:45 --> Loader Class Initialized
INFO - 2024-12-27 12:20:45 --> Helper loaded: url_helper
INFO - 2024-12-27 12:20:45 --> Helper loaded: form_helper
INFO - 2024-12-27 12:20:45 --> Database Driver Class Initialized
INFO - 2024-12-27 12:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:20:45 --> Controller Class Initialized
INFO - 2024-12-27 12:20:45 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:20:45 --> Final output sent to browser
DEBUG - 2024-12-27 12:20:45 --> Total execution time: 0.0443
INFO - 2024-12-27 12:22:26 --> Config Class Initialized
INFO - 2024-12-27 12:22:26 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:22:26 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:22:26 --> Utf8 Class Initialized
INFO - 2024-12-27 12:22:26 --> URI Class Initialized
INFO - 2024-12-27 12:22:26 --> Router Class Initialized
INFO - 2024-12-27 12:22:26 --> Output Class Initialized
INFO - 2024-12-27 12:22:26 --> Security Class Initialized
DEBUG - 2024-12-27 12:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:22:26 --> Input Class Initialized
INFO - 2024-12-27 12:22:26 --> Language Class Initialized
INFO - 2024-12-27 12:22:26 --> Loader Class Initialized
INFO - 2024-12-27 12:22:26 --> Helper loaded: url_helper
INFO - 2024-12-27 12:22:26 --> Helper loaded: form_helper
INFO - 2024-12-27 12:22:26 --> Database Driver Class Initialized
INFO - 2024-12-27 12:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:22:26 --> Controller Class Initialized
INFO - 2024-12-27 12:22:26 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:22:26 --> Final output sent to browser
DEBUG - 2024-12-27 12:22:26 --> Total execution time: 0.0396
INFO - 2024-12-27 12:22:27 --> Config Class Initialized
INFO - 2024-12-27 12:22:27 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:22:27 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:22:27 --> Utf8 Class Initialized
INFO - 2024-12-27 12:22:27 --> URI Class Initialized
INFO - 2024-12-27 12:22:27 --> Router Class Initialized
INFO - 2024-12-27 12:22:27 --> Output Class Initialized
INFO - 2024-12-27 12:22:27 --> Security Class Initialized
DEBUG - 2024-12-27 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:22:27 --> Input Class Initialized
INFO - 2024-12-27 12:22:27 --> Language Class Initialized
ERROR - 2024-12-27 12:22:27 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:22:29 --> Config Class Initialized
INFO - 2024-12-27 12:22:29 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:22:29 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:22:29 --> Utf8 Class Initialized
INFO - 2024-12-27 12:22:29 --> URI Class Initialized
INFO - 2024-12-27 12:22:29 --> Router Class Initialized
INFO - 2024-12-27 12:22:29 --> Output Class Initialized
INFO - 2024-12-27 12:22:29 --> Security Class Initialized
DEBUG - 2024-12-27 12:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:22:29 --> Input Class Initialized
INFO - 2024-12-27 12:22:29 --> Language Class Initialized
INFO - 2024-12-27 12:22:29 --> Loader Class Initialized
INFO - 2024-12-27 12:22:29 --> Helper loaded: url_helper
INFO - 2024-12-27 12:22:29 --> Helper loaded: form_helper
INFO - 2024-12-27 12:22:29 --> Database Driver Class Initialized
INFO - 2024-12-27 12:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:22:29 --> Controller Class Initialized
INFO - 2024-12-27 12:22:29 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:22:29 --> Final output sent to browser
DEBUG - 2024-12-27 12:22:29 --> Total execution time: 0.0341
INFO - 2024-12-27 12:23:24 --> Config Class Initialized
INFO - 2024-12-27 12:23:24 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:23:24 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:23:24 --> Utf8 Class Initialized
INFO - 2024-12-27 12:23:24 --> URI Class Initialized
INFO - 2024-12-27 12:23:24 --> Router Class Initialized
INFO - 2024-12-27 12:23:24 --> Output Class Initialized
INFO - 2024-12-27 12:23:24 --> Security Class Initialized
DEBUG - 2024-12-27 12:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:23:24 --> Input Class Initialized
INFO - 2024-12-27 12:23:24 --> Language Class Initialized
INFO - 2024-12-27 12:23:24 --> Loader Class Initialized
INFO - 2024-12-27 12:23:24 --> Helper loaded: url_helper
INFO - 2024-12-27 12:23:24 --> Helper loaded: form_helper
INFO - 2024-12-27 12:23:24 --> Database Driver Class Initialized
INFO - 2024-12-27 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:23:24 --> Controller Class Initialized
INFO - 2024-12-27 12:23:24 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:23:24 --> Final output sent to browser
DEBUG - 2024-12-27 12:23:24 --> Total execution time: 0.0433
INFO - 2024-12-27 12:23:25 --> Config Class Initialized
INFO - 2024-12-27 12:23:25 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:23:25 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:23:25 --> Utf8 Class Initialized
INFO - 2024-12-27 12:23:25 --> URI Class Initialized
INFO - 2024-12-27 12:23:25 --> Router Class Initialized
INFO - 2024-12-27 12:23:25 --> Output Class Initialized
INFO - 2024-12-27 12:23:25 --> Security Class Initialized
DEBUG - 2024-12-27 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:23:25 --> Input Class Initialized
INFO - 2024-12-27 12:23:25 --> Language Class Initialized
INFO - 2024-12-27 12:23:25 --> Loader Class Initialized
INFO - 2024-12-27 12:23:25 --> Helper loaded: url_helper
INFO - 2024-12-27 12:23:25 --> Helper loaded: form_helper
INFO - 2024-12-27 12:23:25 --> Database Driver Class Initialized
INFO - 2024-12-27 12:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:23:25 --> Controller Class Initialized
INFO - 2024-12-27 12:23:25 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:23:25 --> Final output sent to browser
DEBUG - 2024-12-27 12:23:25 --> Total execution time: 0.0325
INFO - 2024-12-27 12:23:25 --> Config Class Initialized
INFO - 2024-12-27 12:23:25 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:23:25 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:23:25 --> Utf8 Class Initialized
INFO - 2024-12-27 12:23:25 --> URI Class Initialized
INFO - 2024-12-27 12:23:25 --> Router Class Initialized
INFO - 2024-12-27 12:23:25 --> Output Class Initialized
INFO - 2024-12-27 12:23:25 --> Security Class Initialized
DEBUG - 2024-12-27 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:23:25 --> Input Class Initialized
INFO - 2024-12-27 12:23:25 --> Language Class Initialized
INFO - 2024-12-27 12:23:25 --> Loader Class Initialized
INFO - 2024-12-27 12:23:25 --> Helper loaded: url_helper
INFO - 2024-12-27 12:23:25 --> Helper loaded: form_helper
INFO - 2024-12-27 12:23:25 --> Database Driver Class Initialized
INFO - 2024-12-27 12:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:23:25 --> Controller Class Initialized
INFO - 2024-12-27 12:23:25 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:23:25 --> Final output sent to browser
DEBUG - 2024-12-27 12:23:25 --> Total execution time: 0.0302
INFO - 2024-12-27 12:23:25 --> Config Class Initialized
INFO - 2024-12-27 12:23:25 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:23:25 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:23:25 --> Utf8 Class Initialized
INFO - 2024-12-27 12:23:25 --> URI Class Initialized
INFO - 2024-12-27 12:23:25 --> Router Class Initialized
INFO - 2024-12-27 12:23:25 --> Output Class Initialized
INFO - 2024-12-27 12:23:25 --> Security Class Initialized
DEBUG - 2024-12-27 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:23:25 --> Input Class Initialized
INFO - 2024-12-27 12:23:25 --> Language Class Initialized
INFO - 2024-12-27 12:23:25 --> Loader Class Initialized
INFO - 2024-12-27 12:23:25 --> Helper loaded: url_helper
INFO - 2024-12-27 12:23:25 --> Helper loaded: form_helper
INFO - 2024-12-27 12:23:25 --> Database Driver Class Initialized
INFO - 2024-12-27 12:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:23:25 --> Controller Class Initialized
INFO - 2024-12-27 12:23:25 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:23:25 --> Final output sent to browser
DEBUG - 2024-12-27 12:23:25 --> Total execution time: 0.0559
INFO - 2024-12-27 12:23:26 --> Config Class Initialized
INFO - 2024-12-27 12:23:26 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:23:26 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:23:26 --> Utf8 Class Initialized
INFO - 2024-12-27 12:23:26 --> URI Class Initialized
INFO - 2024-12-27 12:23:26 --> Router Class Initialized
INFO - 2024-12-27 12:23:26 --> Output Class Initialized
INFO - 2024-12-27 12:23:26 --> Security Class Initialized
DEBUG - 2024-12-27 12:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:23:26 --> Input Class Initialized
INFO - 2024-12-27 12:23:26 --> Language Class Initialized
INFO - 2024-12-27 12:23:26 --> Loader Class Initialized
INFO - 2024-12-27 12:23:26 --> Helper loaded: url_helper
INFO - 2024-12-27 12:23:26 --> Helper loaded: form_helper
INFO - 2024-12-27 12:23:26 --> Database Driver Class Initialized
INFO - 2024-12-27 12:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:23:26 --> Controller Class Initialized
INFO - 2024-12-27 12:23:26 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:23:26 --> Final output sent to browser
DEBUG - 2024-12-27 12:23:26 --> Total execution time: 0.0292
INFO - 2024-12-27 12:23:26 --> Config Class Initialized
INFO - 2024-12-27 12:23:26 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:23:26 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:23:26 --> Utf8 Class Initialized
INFO - 2024-12-27 12:23:26 --> URI Class Initialized
INFO - 2024-12-27 12:23:26 --> Router Class Initialized
INFO - 2024-12-27 12:23:26 --> Output Class Initialized
INFO - 2024-12-27 12:23:26 --> Security Class Initialized
DEBUG - 2024-12-27 12:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:23:26 --> Input Class Initialized
INFO - 2024-12-27 12:23:26 --> Language Class Initialized
INFO - 2024-12-27 12:23:26 --> Loader Class Initialized
INFO - 2024-12-27 12:23:26 --> Helper loaded: url_helper
INFO - 2024-12-27 12:23:26 --> Helper loaded: form_helper
INFO - 2024-12-27 12:23:26 --> Database Driver Class Initialized
INFO - 2024-12-27 12:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:23:26 --> Controller Class Initialized
INFO - 2024-12-27 12:23:26 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:23:26 --> Final output sent to browser
DEBUG - 2024-12-27 12:23:26 --> Total execution time: 0.0291
INFO - 2024-12-27 12:23:27 --> Config Class Initialized
INFO - 2024-12-27 12:23:27 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:23:27 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:23:27 --> Utf8 Class Initialized
INFO - 2024-12-27 12:23:27 --> URI Class Initialized
INFO - 2024-12-27 12:23:27 --> Router Class Initialized
INFO - 2024-12-27 12:23:27 --> Output Class Initialized
INFO - 2024-12-27 12:23:27 --> Security Class Initialized
DEBUG - 2024-12-27 12:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:23:27 --> Input Class Initialized
INFO - 2024-12-27 12:23:27 --> Language Class Initialized
ERROR - 2024-12-27 12:23:27 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:25:05 --> Config Class Initialized
INFO - 2024-12-27 12:25:05 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:25:05 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:25:05 --> Utf8 Class Initialized
INFO - 2024-12-27 12:25:05 --> URI Class Initialized
INFO - 2024-12-27 12:25:05 --> Router Class Initialized
INFO - 2024-12-27 12:25:05 --> Output Class Initialized
INFO - 2024-12-27 12:25:05 --> Security Class Initialized
DEBUG - 2024-12-27 12:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:25:05 --> Input Class Initialized
INFO - 2024-12-27 12:25:05 --> Language Class Initialized
INFO - 2024-12-27 12:25:05 --> Loader Class Initialized
INFO - 2024-12-27 12:25:05 --> Helper loaded: url_helper
INFO - 2024-12-27 12:25:05 --> Helper loaded: form_helper
INFO - 2024-12-27 12:25:05 --> Database Driver Class Initialized
INFO - 2024-12-27 12:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:25:05 --> Controller Class Initialized
INFO - 2024-12-27 12:25:05 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:25:05 --> Final output sent to browser
DEBUG - 2024-12-27 12:25:05 --> Total execution time: 0.0373
INFO - 2024-12-27 12:25:05 --> Config Class Initialized
INFO - 2024-12-27 12:25:05 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:25:05 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:25:05 --> Utf8 Class Initialized
INFO - 2024-12-27 12:25:05 --> URI Class Initialized
INFO - 2024-12-27 12:25:05 --> Router Class Initialized
INFO - 2024-12-27 12:25:05 --> Output Class Initialized
INFO - 2024-12-27 12:25:05 --> Security Class Initialized
DEBUG - 2024-12-27 12:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:25:05 --> Input Class Initialized
INFO - 2024-12-27 12:25:05 --> Language Class Initialized
ERROR - 2024-12-27 12:25:05 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:25:06 --> Config Class Initialized
INFO - 2024-12-27 12:25:06 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:25:06 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:25:06 --> Utf8 Class Initialized
INFO - 2024-12-27 12:25:06 --> URI Class Initialized
INFO - 2024-12-27 12:25:06 --> Router Class Initialized
INFO - 2024-12-27 12:25:06 --> Output Class Initialized
INFO - 2024-12-27 12:25:06 --> Security Class Initialized
DEBUG - 2024-12-27 12:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:25:06 --> Input Class Initialized
INFO - 2024-12-27 12:25:06 --> Language Class Initialized
INFO - 2024-12-27 12:25:06 --> Loader Class Initialized
INFO - 2024-12-27 12:25:06 --> Helper loaded: url_helper
INFO - 2024-12-27 12:25:06 --> Helper loaded: form_helper
INFO - 2024-12-27 12:25:06 --> Database Driver Class Initialized
INFO - 2024-12-27 12:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:25:06 --> Controller Class Initialized
INFO - 2024-12-27 12:25:06 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:25:06 --> Final output sent to browser
DEBUG - 2024-12-27 12:25:06 --> Total execution time: 0.0314
INFO - 2024-12-27 12:25:41 --> Config Class Initialized
INFO - 2024-12-27 12:25:41 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:25:41 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:25:41 --> Utf8 Class Initialized
INFO - 2024-12-27 12:25:41 --> URI Class Initialized
INFO - 2024-12-27 12:25:41 --> Router Class Initialized
INFO - 2024-12-27 12:25:41 --> Output Class Initialized
INFO - 2024-12-27 12:25:41 --> Security Class Initialized
DEBUG - 2024-12-27 12:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:25:41 --> Input Class Initialized
INFO - 2024-12-27 12:25:41 --> Language Class Initialized
INFO - 2024-12-27 12:25:41 --> Loader Class Initialized
INFO - 2024-12-27 12:25:41 --> Helper loaded: url_helper
INFO - 2024-12-27 12:25:41 --> Helper loaded: form_helper
INFO - 2024-12-27 12:25:41 --> Database Driver Class Initialized
INFO - 2024-12-27 12:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:25:41 --> Controller Class Initialized
INFO - 2024-12-27 12:25:41 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:25:41 --> Final output sent to browser
DEBUG - 2024-12-27 12:25:41 --> Total execution time: 0.0638
INFO - 2024-12-27 12:25:47 --> Config Class Initialized
INFO - 2024-12-27 12:25:47 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:25:47 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:25:47 --> Utf8 Class Initialized
INFO - 2024-12-27 12:25:47 --> URI Class Initialized
INFO - 2024-12-27 12:25:47 --> Router Class Initialized
INFO - 2024-12-27 12:25:47 --> Output Class Initialized
INFO - 2024-12-27 12:25:47 --> Security Class Initialized
DEBUG - 2024-12-27 12:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:25:47 --> Input Class Initialized
INFO - 2024-12-27 12:25:47 --> Language Class Initialized
INFO - 2024-12-27 12:25:47 --> Loader Class Initialized
INFO - 2024-12-27 12:25:47 --> Helper loaded: url_helper
INFO - 2024-12-27 12:25:47 --> Helper loaded: form_helper
INFO - 2024-12-27 12:25:47 --> Database Driver Class Initialized
INFO - 2024-12-27 12:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:25:47 --> Controller Class Initialized
INFO - 2024-12-27 12:25:47 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:25:47 --> Final output sent to browser
DEBUG - 2024-12-27 12:25:47 --> Total execution time: 0.0388
INFO - 2024-12-27 12:25:47 --> Config Class Initialized
INFO - 2024-12-27 12:25:47 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:25:47 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:25:47 --> Utf8 Class Initialized
INFO - 2024-12-27 12:25:47 --> URI Class Initialized
INFO - 2024-12-27 12:25:47 --> Router Class Initialized
INFO - 2024-12-27 12:25:47 --> Output Class Initialized
INFO - 2024-12-27 12:25:47 --> Security Class Initialized
DEBUG - 2024-12-27 12:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:25:47 --> Input Class Initialized
INFO - 2024-12-27 12:25:47 --> Language Class Initialized
INFO - 2024-12-27 12:25:47 --> Loader Class Initialized
INFO - 2024-12-27 12:25:47 --> Helper loaded: url_helper
INFO - 2024-12-27 12:25:47 --> Helper loaded: form_helper
INFO - 2024-12-27 12:25:47 --> Database Driver Class Initialized
INFO - 2024-12-27 12:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:25:47 --> Controller Class Initialized
INFO - 2024-12-27 12:25:47 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:25:47 --> Final output sent to browser
DEBUG - 2024-12-27 12:25:47 --> Total execution time: 0.0314
INFO - 2024-12-27 12:25:48 --> Config Class Initialized
INFO - 2024-12-27 12:25:48 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:25:48 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:25:48 --> Utf8 Class Initialized
INFO - 2024-12-27 12:25:48 --> URI Class Initialized
INFO - 2024-12-27 12:25:48 --> Router Class Initialized
INFO - 2024-12-27 12:25:48 --> Output Class Initialized
INFO - 2024-12-27 12:25:48 --> Security Class Initialized
DEBUG - 2024-12-27 12:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:25:48 --> Input Class Initialized
INFO - 2024-12-27 12:25:48 --> Language Class Initialized
ERROR - 2024-12-27 12:25:48 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:25:49 --> Config Class Initialized
INFO - 2024-12-27 12:25:49 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:25:49 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:25:49 --> Utf8 Class Initialized
INFO - 2024-12-27 12:25:49 --> URI Class Initialized
INFO - 2024-12-27 12:25:49 --> Router Class Initialized
INFO - 2024-12-27 12:25:49 --> Output Class Initialized
INFO - 2024-12-27 12:25:49 --> Security Class Initialized
DEBUG - 2024-12-27 12:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:25:49 --> Input Class Initialized
INFO - 2024-12-27 12:25:49 --> Language Class Initialized
INFO - 2024-12-27 12:25:49 --> Loader Class Initialized
INFO - 2024-12-27 12:25:49 --> Helper loaded: url_helper
INFO - 2024-12-27 12:25:49 --> Helper loaded: form_helper
INFO - 2024-12-27 12:25:49 --> Database Driver Class Initialized
INFO - 2024-12-27 12:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:25:49 --> Controller Class Initialized
INFO - 2024-12-27 12:25:49 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:25:49 --> Final output sent to browser
DEBUG - 2024-12-27 12:25:49 --> Total execution time: 0.0421
INFO - 2024-12-27 12:26:09 --> Config Class Initialized
INFO - 2024-12-27 12:26:09 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:09 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:09 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:09 --> URI Class Initialized
INFO - 2024-12-27 12:26:09 --> Router Class Initialized
INFO - 2024-12-27 12:26:09 --> Output Class Initialized
INFO - 2024-12-27 12:26:09 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:09 --> Input Class Initialized
INFO - 2024-12-27 12:26:09 --> Language Class Initialized
INFO - 2024-12-27 12:26:09 --> Loader Class Initialized
INFO - 2024-12-27 12:26:09 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:09 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:09 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:09 --> Controller Class Initialized
INFO - 2024-12-27 12:26:09 --> Form Validation Class Initialized
DEBUG - 2024-12-27 12:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-27 12:26:09 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\tambah_kue.php
INFO - 2024-12-27 12:26:09 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:09 --> Total execution time: 0.0479
INFO - 2024-12-27 12:26:10 --> Config Class Initialized
INFO - 2024-12-27 12:26:10 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:10 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:10 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:10 --> URI Class Initialized
INFO - 2024-12-27 12:26:10 --> Router Class Initialized
INFO - 2024-12-27 12:26:10 --> Output Class Initialized
INFO - 2024-12-27 12:26:10 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:10 --> Input Class Initialized
INFO - 2024-12-27 12:26:10 --> Language Class Initialized
INFO - 2024-12-27 12:26:10 --> Loader Class Initialized
INFO - 2024-12-27 12:26:10 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:10 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:10 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:10 --> Controller Class Initialized
INFO - 2024-12-27 12:26:10 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:26:10 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:10 --> Total execution time: 0.0440
INFO - 2024-12-27 12:26:11 --> Config Class Initialized
INFO - 2024-12-27 12:26:11 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:11 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:11 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:11 --> URI Class Initialized
INFO - 2024-12-27 12:26:11 --> Router Class Initialized
INFO - 2024-12-27 12:26:11 --> Output Class Initialized
INFO - 2024-12-27 12:26:11 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:11 --> Input Class Initialized
INFO - 2024-12-27 12:26:11 --> Language Class Initialized
INFO - 2024-12-27 12:26:11 --> Loader Class Initialized
INFO - 2024-12-27 12:26:11 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:11 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:11 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:11 --> Controller Class Initialized
INFO - 2024-12-27 12:26:11 --> Form Validation Class Initialized
DEBUG - 2024-12-27 12:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-27 12:26:11 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\tambah_kue.php
INFO - 2024-12-27 12:26:11 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:11 --> Total execution time: 0.0372
INFO - 2024-12-27 12:26:21 --> Config Class Initialized
INFO - 2024-12-27 12:26:21 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:21 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:21 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:21 --> URI Class Initialized
INFO - 2024-12-27 12:26:21 --> Router Class Initialized
INFO - 2024-12-27 12:26:21 --> Output Class Initialized
INFO - 2024-12-27 12:26:21 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:21 --> Input Class Initialized
INFO - 2024-12-27 12:26:21 --> Language Class Initialized
INFO - 2024-12-27 12:26:21 --> Loader Class Initialized
INFO - 2024-12-27 12:26:21 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:21 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:21 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:21 --> Controller Class Initialized
INFO - 2024-12-27 12:26:21 --> Form Validation Class Initialized
DEBUG - 2024-12-27 12:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-27 12:26:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-27 12:26:21 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\tambah_kue.php
INFO - 2024-12-27 12:26:21 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:21 --> Total execution time: 0.0376
INFO - 2024-12-27 12:26:24 --> Config Class Initialized
INFO - 2024-12-27 12:26:24 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:24 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:24 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:24 --> URI Class Initialized
INFO - 2024-12-27 12:26:24 --> Router Class Initialized
INFO - 2024-12-27 12:26:24 --> Output Class Initialized
INFO - 2024-12-27 12:26:24 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:24 --> Input Class Initialized
INFO - 2024-12-27 12:26:24 --> Language Class Initialized
INFO - 2024-12-27 12:26:24 --> Loader Class Initialized
INFO - 2024-12-27 12:26:24 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:24 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:24 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:24 --> Controller Class Initialized
INFO - 2024-12-27 12:26:24 --> Form Validation Class Initialized
DEBUG - 2024-12-27 12:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-27 12:26:24 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\tambah_kue.php
INFO - 2024-12-27 12:26:24 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:24 --> Total execution time: 0.0429
INFO - 2024-12-27 12:26:24 --> Config Class Initialized
INFO - 2024-12-27 12:26:24 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:24 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:24 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:24 --> URI Class Initialized
INFO - 2024-12-27 12:26:24 --> Router Class Initialized
INFO - 2024-12-27 12:26:24 --> Output Class Initialized
INFO - 2024-12-27 12:26:24 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:24 --> Input Class Initialized
INFO - 2024-12-27 12:26:24 --> Language Class Initialized
INFO - 2024-12-27 12:26:24 --> Loader Class Initialized
INFO - 2024-12-27 12:26:24 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:24 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:24 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:24 --> Controller Class Initialized
INFO - 2024-12-27 12:26:24 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:26:24 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:24 --> Total execution time: 0.0461
INFO - 2024-12-27 12:26:25 --> Config Class Initialized
INFO - 2024-12-27 12:26:25 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:25 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:25 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:25 --> URI Class Initialized
INFO - 2024-12-27 12:26:25 --> Router Class Initialized
INFO - 2024-12-27 12:26:25 --> Output Class Initialized
INFO - 2024-12-27 12:26:25 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:25 --> Input Class Initialized
INFO - 2024-12-27 12:26:25 --> Language Class Initialized
INFO - 2024-12-27 12:26:25 --> Loader Class Initialized
INFO - 2024-12-27 12:26:25 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:25 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:25 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:25 --> Controller Class Initialized
INFO - 2024-12-27 12:26:25 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:26:25 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:25 --> Total execution time: 0.0555
INFO - 2024-12-27 12:26:25 --> Config Class Initialized
INFO - 2024-12-27 12:26:25 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:25 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:25 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:25 --> URI Class Initialized
INFO - 2024-12-27 12:26:25 --> Router Class Initialized
INFO - 2024-12-27 12:26:25 --> Output Class Initialized
INFO - 2024-12-27 12:26:25 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:25 --> Input Class Initialized
INFO - 2024-12-27 12:26:25 --> Language Class Initialized
INFO - 2024-12-27 12:26:25 --> Loader Class Initialized
INFO - 2024-12-27 12:26:25 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:25 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:25 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:25 --> Controller Class Initialized
INFO - 2024-12-27 12:26:25 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:26:25 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:25 --> Total execution time: 0.0406
INFO - 2024-12-27 12:26:26 --> Config Class Initialized
INFO - 2024-12-27 12:26:26 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:26:26 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:26:26 --> Utf8 Class Initialized
INFO - 2024-12-27 12:26:26 --> URI Class Initialized
INFO - 2024-12-27 12:26:26 --> Router Class Initialized
INFO - 2024-12-27 12:26:26 --> Output Class Initialized
INFO - 2024-12-27 12:26:26 --> Security Class Initialized
DEBUG - 2024-12-27 12:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:26:26 --> Input Class Initialized
INFO - 2024-12-27 12:26:26 --> Language Class Initialized
INFO - 2024-12-27 12:26:26 --> Loader Class Initialized
INFO - 2024-12-27 12:26:26 --> Helper loaded: url_helper
INFO - 2024-12-27 12:26:26 --> Helper loaded: form_helper
INFO - 2024-12-27 12:26:26 --> Database Driver Class Initialized
INFO - 2024-12-27 12:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:26:26 --> Controller Class Initialized
INFO - 2024-12-27 12:26:26 --> Form Validation Class Initialized
DEBUG - 2024-12-27 12:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-12-27 12:26:26 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\tambah_kue.php
INFO - 2024-12-27 12:26:26 --> Final output sent to browser
DEBUG - 2024-12-27 12:26:26 --> Total execution time: 0.0325
INFO - 2024-12-27 12:36:28 --> Config Class Initialized
INFO - 2024-12-27 12:36:28 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:36:28 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:36:28 --> Utf8 Class Initialized
INFO - 2024-12-27 12:36:28 --> URI Class Initialized
INFO - 2024-12-27 12:36:28 --> Router Class Initialized
INFO - 2024-12-27 12:36:28 --> Output Class Initialized
INFO - 2024-12-27 12:36:28 --> Security Class Initialized
DEBUG - 2024-12-27 12:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:36:28 --> Input Class Initialized
INFO - 2024-12-27 12:36:28 --> Language Class Initialized
INFO - 2024-12-27 12:36:28 --> Loader Class Initialized
INFO - 2024-12-27 12:36:28 --> Helper loaded: url_helper
INFO - 2024-12-27 12:36:28 --> Helper loaded: form_helper
INFO - 2024-12-27 12:36:28 --> Database Driver Class Initialized
INFO - 2024-12-27 12:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:36:28 --> Controller Class Initialized
INFO - 2024-12-27 12:36:28 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:36:28 --> Final output sent to browser
DEBUG - 2024-12-27 12:36:28 --> Total execution time: 0.0464
INFO - 2024-12-27 12:36:29 --> Config Class Initialized
INFO - 2024-12-27 12:36:29 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:36:29 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:36:29 --> Utf8 Class Initialized
INFO - 2024-12-27 12:36:29 --> URI Class Initialized
INFO - 2024-12-27 12:36:29 --> Router Class Initialized
INFO - 2024-12-27 12:36:29 --> Output Class Initialized
INFO - 2024-12-27 12:36:29 --> Security Class Initialized
DEBUG - 2024-12-27 12:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:36:29 --> Input Class Initialized
INFO - 2024-12-27 12:36:29 --> Language Class Initialized
ERROR - 2024-12-27 12:36:29 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:36:57 --> Config Class Initialized
INFO - 2024-12-27 12:36:57 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:36:57 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:36:57 --> Utf8 Class Initialized
INFO - 2024-12-27 12:36:57 --> URI Class Initialized
INFO - 2024-12-27 12:36:57 --> Router Class Initialized
INFO - 2024-12-27 12:36:57 --> Output Class Initialized
INFO - 2024-12-27 12:36:57 --> Security Class Initialized
DEBUG - 2024-12-27 12:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:36:57 --> Input Class Initialized
INFO - 2024-12-27 12:36:57 --> Language Class Initialized
ERROR - 2024-12-27 12:36:57 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:36:58 --> Config Class Initialized
INFO - 2024-12-27 12:36:58 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:36:58 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:36:58 --> Utf8 Class Initialized
INFO - 2024-12-27 12:36:58 --> URI Class Initialized
INFO - 2024-12-27 12:36:58 --> Router Class Initialized
INFO - 2024-12-27 12:36:58 --> Output Class Initialized
INFO - 2024-12-27 12:36:58 --> Security Class Initialized
DEBUG - 2024-12-27 12:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:36:58 --> Input Class Initialized
INFO - 2024-12-27 12:36:58 --> Language Class Initialized
INFO - 2024-12-27 12:36:58 --> Loader Class Initialized
INFO - 2024-12-27 12:36:58 --> Helper loaded: url_helper
INFO - 2024-12-27 12:36:58 --> Helper loaded: form_helper
INFO - 2024-12-27 12:36:58 --> Database Driver Class Initialized
INFO - 2024-12-27 12:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:36:58 --> Controller Class Initialized
INFO - 2024-12-27 12:36:58 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:36:58 --> Final output sent to browser
DEBUG - 2024-12-27 12:36:58 --> Total execution time: 0.0292
INFO - 2024-12-27 12:37:17 --> Config Class Initialized
INFO - 2024-12-27 12:37:17 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:37:17 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:37:17 --> Utf8 Class Initialized
INFO - 2024-12-27 12:37:17 --> URI Class Initialized
INFO - 2024-12-27 12:37:17 --> Router Class Initialized
INFO - 2024-12-27 12:37:17 --> Output Class Initialized
INFO - 2024-12-27 12:37:17 --> Security Class Initialized
DEBUG - 2024-12-27 12:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:37:17 --> Input Class Initialized
INFO - 2024-12-27 12:37:17 --> Language Class Initialized
INFO - 2024-12-27 12:37:17 --> Loader Class Initialized
INFO - 2024-12-27 12:37:17 --> Helper loaded: url_helper
INFO - 2024-12-27 12:37:17 --> Helper loaded: form_helper
INFO - 2024-12-27 12:37:17 --> Database Driver Class Initialized
INFO - 2024-12-27 12:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:37:17 --> Controller Class Initialized
INFO - 2024-12-27 12:37:17 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:37:17 --> Final output sent to browser
DEBUG - 2024-12-27 12:37:17 --> Total execution time: 0.0302
INFO - 2024-12-27 12:37:18 --> Config Class Initialized
INFO - 2024-12-27 12:37:18 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:37:18 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:37:18 --> Utf8 Class Initialized
INFO - 2024-12-27 12:37:18 --> URI Class Initialized
INFO - 2024-12-27 12:37:18 --> Router Class Initialized
INFO - 2024-12-27 12:37:18 --> Output Class Initialized
INFO - 2024-12-27 12:37:18 --> Security Class Initialized
DEBUG - 2024-12-27 12:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:37:18 --> Input Class Initialized
INFO - 2024-12-27 12:37:18 --> Language Class Initialized
ERROR - 2024-12-27 12:37:18 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:37:19 --> Config Class Initialized
INFO - 2024-12-27 12:37:19 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:37:19 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:37:19 --> Utf8 Class Initialized
INFO - 2024-12-27 12:37:19 --> URI Class Initialized
INFO - 2024-12-27 12:37:19 --> Router Class Initialized
INFO - 2024-12-27 12:37:19 --> Output Class Initialized
INFO - 2024-12-27 12:37:19 --> Security Class Initialized
DEBUG - 2024-12-27 12:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:37:19 --> Input Class Initialized
INFO - 2024-12-27 12:37:19 --> Language Class Initialized
INFO - 2024-12-27 12:37:19 --> Loader Class Initialized
INFO - 2024-12-27 12:37:19 --> Helper loaded: url_helper
INFO - 2024-12-27 12:37:19 --> Helper loaded: form_helper
INFO - 2024-12-27 12:37:19 --> Database Driver Class Initialized
INFO - 2024-12-27 12:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 12:37:19 --> Controller Class Initialized
INFO - 2024-12-27 12:37:19 --> File loaded: C:\xampp\htdocs\velo_bakery\application\views\admin_kue.php
INFO - 2024-12-27 12:37:19 --> Final output sent to browser
DEBUG - 2024-12-27 12:37:19 --> Total execution time: 0.0403
INFO - 2024-12-27 12:40:20 --> Config Class Initialized
INFO - 2024-12-27 12:40:20 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:40:20 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:40:20 --> Utf8 Class Initialized
INFO - 2024-12-27 12:40:20 --> URI Class Initialized
INFO - 2024-12-27 12:40:20 --> Router Class Initialized
INFO - 2024-12-27 12:40:20 --> Output Class Initialized
INFO - 2024-12-27 12:40:20 --> Security Class Initialized
DEBUG - 2024-12-27 12:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:40:20 --> Input Class Initialized
INFO - 2024-12-27 12:40:20 --> Language Class Initialized
ERROR - 2024-12-27 12:40:20 --> 404 Page Not Found: Edit_kue/1
INFO - 2024-12-27 12:40:47 --> Config Class Initialized
INFO - 2024-12-27 12:40:47 --> Hooks Class Initialized
DEBUG - 2024-12-27 12:40:47 --> UTF-8 Support Enabled
INFO - 2024-12-27 12:40:47 --> Utf8 Class Initialized
INFO - 2024-12-27 12:40:47 --> URI Class Initialized
INFO - 2024-12-27 12:40:47 --> Router Class Initialized
INFO - 2024-12-27 12:40:47 --> Output Class Initialized
INFO - 2024-12-27 12:40:47 --> Security Class Initialized
DEBUG - 2024-12-27 12:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 12:40:47 --> Input Class Initialized
INFO - 2024-12-27 12:40:47 --> Language Class Initialized
ERROR - 2024-12-27 12:40:47 --> 404 Page Not Found: Edit_kue/1
